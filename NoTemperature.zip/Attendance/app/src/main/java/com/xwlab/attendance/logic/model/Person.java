package com.xwlab.attendance.logic.model;

public class Person {
    String phoneNum,name,feature,password;
    public Person(String phoneNum, String name, String feature, String password) {
        this.phoneNum = phoneNum;
        this.name = name;
        this.feature = feature;
        this.password = password;
    }
}
