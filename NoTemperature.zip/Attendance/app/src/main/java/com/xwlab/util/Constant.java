package com.xwlab.util;

public class Constant {
    public static final int CLOSE_FACE = 1;
    public static final int WELCOME = 2;            //欢迎
    public static final int UNKNOWN = 3;            //未知人员
    public static final int CLEAN_TEXT = 4;         //清除文本
    public static final int VERIFY_SUCCESSFULLY = 5;//验证成功
    public static final int LIVE_DETECT = 7;        //
    public static final int EXPRESSION = 8;
    public static final int CLEAN_EXPRESSION_AND_TEMPERATURE = 9;   //清除表情和温度
}
